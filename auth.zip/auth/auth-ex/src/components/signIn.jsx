import React, { useState } from 'react'
import { reg } from '../actions/user'
import Input from '../util/Input'

const SignIn = () => {

    const [ email, setEmail ] = useState('')
    const [ password, setPassword ] = useState('')
    const [ firstName, setFirstName ] = useState('')
    const [ lastName, setLastName ] = useState('')
    

    const regHandler = async (e) => {
        e.preventDefault()
        try {
            const data = await reg(email, password)
            console.log(reg.messaage);
        } catch (e) {
            console.log(e);
        }
    }

    return(
        <div>
            <div className="container">
                <form className="white">
                    <h2>Вход</h2>
                    <div className="input-field">
                        <label htmlFor="firstName">First Name</label>
                        <Input value={firstName} setValue={setFirstName}  type="text"/>
                        <div className="input-field">
                            <label htmlFor="lastName">Last Name</label>
                            <Input value={lastName} setValue={setLastName} type="text" />
                        </div>
                        <div className="input-field">
                            <label htmlFor="email">E-mail</label>
                            <Input value={email} setValue={setEmail} type="text"/>
                        </div>
                        <div className="input-field">
                            <label htmlFor="password">Password</label>
                            <Input value={password} setValue={setPassword} type="password"/>
                        </div>
                        <div className="input-field">
                            <button onClick={regHandler} className="btn pink lighten-3 z-depth-0">Войти</button>
                        </div>
                    </div>
              </form>
            </div>
        </div>
    )
}

export default SignIn