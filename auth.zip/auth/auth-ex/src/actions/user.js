import axios from 'axios'

export const reg = async (email, password, firstName, lastName, e) => {
    try {
        const res = await axios.post('/api/auth/registration', {
            email,
            password
        })
        alert(res.data.message)
    } catch (e) {
        console.log(e);
        alert(e)
    }

}