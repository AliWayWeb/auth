import React from 'react';
import SignIn from './components/signIn';

function App() {
    return (
        <div className="App">
            <SignIn />
        </div>
    );
}

export default App;
