const { Schema, model, Mongoose } = require('mongoose')

const User = new Schema({
    email: {
        type: String, 
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    firstName: {
        type: String,
    },
    lastName: {
        type: String, 
    }
}, {
    collation: 'User'
})
module.exports = model('User', User)