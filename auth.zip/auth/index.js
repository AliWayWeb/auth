const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const config = require('config')
const app = express()
const PORT = config.get('port')
const url = config.get('url')

app.use(express.json())
app.use(bodyParser.json())

app.use('/api/auth', require('./routes/auth.routes.js'));

const start = async () => {
    try {
        await mongoose.connect(url)
        app.listen(PORT, () => console.log(`Example app listening at http://localhost:${PORT}`))
    } catch(e) {
        console.log(e);
    }
}

start()
